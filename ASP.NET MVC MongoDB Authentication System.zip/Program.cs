using Microsoft.AspNetCore.Authentication.Cookies;
using $safeprojectname$.Core;
using $safeprojectname$.Models;
using $safeprojectname$.Services.db;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

builder.Services.Configure<DatabaseSettings>(builder.Configuration.GetSection(nameof(DatabaseSettings)));

builder.Services.AddSingleton<UsersDbService>();

builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme).AddCookie(options =>
{
    options.LoginPath = "/Auth/Index";
    options.AccessDeniedPath = "/Auth/AccessDenied";
});


var app = builder.Build();

// services scope
using var servicesScope = app.Services.CreateScope();
{
    var services = servicesScope.ServiceProvider;
    var usersDbService = services.GetRequiredService<UsersDbService>();
    if ((await usersDbService.GetAsync()).Count == 0)
    {
        var demoUser1 = new User()
        {
            FullName = "Admin",
            Username = "admin",
            Email = "admin@admin.com",
            Password = "123",
            Role = nameof(UserRole.Admin),
            IsEmailConfirmed = true,
        };
        demoUser1.HashPassword();


        var demoUser2 = new User()
        {
            FullName = "Tester",
            Username = "tester",
            Email = "test@test.com",
            Password = "123",
            Role = nameof(UserRole.User),
            IsEmailConfirmed = true,
        };
        demoUser2.HashPassword();

        await usersDbService.CreateAsync(demoUser1);
        await usersDbService.CreateAsync(demoUser2);
    }
}

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
