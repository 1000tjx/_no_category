﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using System.ComponentModel.DataAnnotations;
using $safeprojectname$.Core;

namespace $safeprojectname$.Models
{
    public enum UserRole
    {
        User,
        Admin
    }

    public class UserIdentity
    {
        public required String Id;
        public required string FullName;
        public required string Role;
    }

    public class User : IMongoDBEntity
    {

        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string? Id { get; set; }

        [Required]
        public string? FullName { get; set; }


        [Required]
        public string? Username { get; set; }


        [Required]
        public string? Email { get; set; }

        [Required]
        public string? Password { get; set; }

        [Required]
        public bool IsEmailConfirmed { get; set; } = false;

        [Required]
        public bool IsLocked { get; set; } = false;


        [Required]
        public string Role { get; set; } = nameof(UserRole.User);



        // thi method will be used to check if the password is correct or not
        public bool VerifyPassword(string passwordToCheck)
        {
            if (passwordToCheck.Trim().Length == 0) return false;
            return BCrypt.Net.BCrypt.Verify(passwordToCheck, Password);
        }


        // hash a given  password
        public void HashPassword()
        {
            Password = BCrypt.Net.BCrypt.HashPassword(Password, workFactor: 5);
        }


    }
}
