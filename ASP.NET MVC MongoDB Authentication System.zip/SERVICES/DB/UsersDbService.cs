﻿using Microsoft.Extensions.Options;
using MongoDB.Driver;
using $safeprojectname$.Core;
using $safeprojectname$.Models;

namespace $safeprojectname$.Services.db
{
    public class UsersDbService : DbContext<User>
    {
        public UsersDbService(IOptions<DatabaseSettings> databaseSettings) : base(databaseSettings, databaseSettings.Value.UsersCollectionName)
        {
        }

        public User? GetUserByEmail(string email)
        {
            return _collection.Find(user => user.Email == email).FirstOrDefault();
        }


        // used for authenticate loginModel
        public UserIdentity? Authenticate(LoginModel loginModel)
        {
            var user = GetUserByEmail(loginModel.Email ?? "");
            if (user == null) return null;
            if (!user.VerifyPassword(loginModel.Password ?? "")) return null;
            return new UserIdentity() { Id = user.Id!, FullName = user.FullName!, Role = user.Role };
        }
    }
}
