﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using $safeprojectname$.Models;
using $safeprojectname$.Services.db;

namespace $safeprojectname$.Controllers
{
    public class AuthController : Controller
    {
        private readonly UsersDbService _usersDbService;
        private readonly ILogger<AuthController> _logger;

        public AuthController(UsersDbService usersDbService, ILogger<AuthController> logger)
        {
            _usersDbService = usersDbService;
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login([Bind] LoginModel loginModel, string? returnUrl = null)

        {
            _logger.LogInformation($"{loginModel}");
            var user = _usersDbService.Authenticate(loginModel);
            if (user == null)
            {
                ViewData["Error"] = true;
                return View("Index", loginModel);
            }
            else
            {
                var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, user.FullName),
                    new Claim(ClaimTypes.Role, user.Role),
                };

                var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                var authProperties = new AuthenticationProperties();

                await HttpContext.SignInAsync(
                    CookieAuthenticationDefaults.AuthenticationScheme,
                    new ClaimsPrincipal(claimsIdentity),
                    authProperties);

                return RedirectToAction(nameof(TestUser), new { returnUrl });
            }
        }


        [Authorize(Roles = nameof(UserRole.Admin))]
        public IActionResult TestAdmin()
        {
            return View();
        }


        [Authorize]
        // [Authorize(Roles = nameof(UserRole.User))]  // uncomment this to allow only "user roles"
        public IActionResult TestUser()
        {
            return View();
        }

        public string AccessDenied()
        {
            return "Access Denied";
        }

        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Index", "Home");
        }
    }
}
