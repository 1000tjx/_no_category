#include "Hello.h"
#include <iostream>

void SayHello()
{
	std::cout << "Hello there!" << std::endl;
}