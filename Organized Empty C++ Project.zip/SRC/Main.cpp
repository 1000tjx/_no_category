#include "Hello.h"

int main()
{
	SayHello();
}