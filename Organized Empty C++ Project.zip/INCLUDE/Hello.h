#pragma once

void SayHello();
