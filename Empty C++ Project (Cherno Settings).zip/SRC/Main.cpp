#include <iostream>

int main()
{
	std::cout << "Hello TJX!!" << std::endl;
}