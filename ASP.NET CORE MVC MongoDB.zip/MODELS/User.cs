﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using ThirdParty.Json.LitJson;
using $safeprojectname$.Core;

namespace $safeprojectname$.Models
{
    public class User : IMongoDBEntity
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = String.Empty;

        [Required]
        public string? Username { get; set; }

        [Required]
        public string? Email { get; set; }
    }

    public class SignupDTO
    {
        [Required]
        public string? Username { get; set; }

        [Required, EmailAddress]
        public string? Email { get; set; }
    

        // this will create a User object
        public User Create()
        {
            return new User
            {
                Username = Username,
                Email = Email,
            };
        }
    }
}
