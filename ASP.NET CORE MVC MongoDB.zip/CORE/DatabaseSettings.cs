﻿namespace $safeprojectname$.Core
{
    public class DatabaseSettings
    {
        // collections
        public required string UsersCollectionName { get; set; }

        // connection string and database name
        public required string ConnectionString { get; set; }
        public required string DatabaseName { get; set; }
    }
}
