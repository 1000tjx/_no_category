﻿namespace $safeprojectname$.Models
{
    public class LoginModel
    {
        public string? Username { get; set; }
        public string? Password { get; set; }

        override public string ToString()
        {
            return $"LoginModel(Username={Username}, Password={Password})";
        }
    }
}
