﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using System.Diagnostics;
using System.Security.Claims;
using $safeprojectname$.Core;
using $safeprojectname$.Models;

namespace $safeprojectname$.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly AdminPanelSettings _adminPanelSettings;

        public HomeController(ILogger<HomeController> logger, IOptions<AdminPanelSettings> adminPanelSettings)
        {
            _logger = logger;
            _adminPanelSettings = adminPanelSettings.Value;
        }

        public IActionResult Index()
        {
            return View();
        }

        [Authorize(Roles = "Admin")]
        public IActionResult Privacy()
        {
            return View();
        }


        [BindProperty]
        public LoginModel LoginModel { get; set; } = new();

        public IActionResult Login()
        {
            return View(LoginModel);
        }


        [HttpPost]
        public async Task<IActionResult> Login(string? returnUrl = null, bool _ = false)
        {
            _logger.LogInformation($"Login data: {LoginModel}");
            AdminUser? user = _adminPanelSettings.AuthenticateUser(LoginModel.Username ?? "", LoginModel.Password ?? "");
            if (user != null)
            {
                var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, user.Username!),
                    new Claim(ClaimTypes.Role, user.Role),
                };
                var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity));
                _logger.LogInformation("User Logged in!");
            }
            else
            {
                _logger.LogInformation("Invalid Credentials!");
            }
            if(returnUrl != null)
            {
                return Redirect(returnUrl);
            }
            else
            {
                return RedirectToAction("Index", "Home");
            }
        }

        public async Task<IActionResult> Logout(string? returnUrl = null)
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Index", "Home");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}