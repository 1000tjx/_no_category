﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using System.Linq;
using $safeprojectname$.Models;
using $safeprojectname$.Services;

namespace $safeprojectname$.Controllers
{
    public class UsersController : Controller
    {
        private readonly UsersDbService _usersDbService;
        private readonly ILogger<UsersController> _logger;

        public UsersController(UsersDbService usersDbService, ILogger<UsersController> logger)
        {
            _usersDbService = usersDbService;
            _logger = logger;
        }

        public async Task<IActionResult> Index()
        {
            var users = await _usersDbService.GetAsync();
            return View(users);
        }


        [HttpGet]
        public IActionResult Signup()
        {
            return View();
        }


        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Signup(SignupDTO user, bool? _)
        {
            if (ModelState.IsValid)
            {
                await _usersDbService.CreateAsync(user.Create());
                return RedirectToAction(nameof(Index));
            }
            return View(user);
        }
    }
}
