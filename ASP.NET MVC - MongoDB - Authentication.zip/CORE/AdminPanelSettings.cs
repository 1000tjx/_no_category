﻿using Microsoft.AspNetCore.DataProtection.AuthenticatedEncryption.ConfigurationModel;
using Microsoft.AspNetCore.Identity;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace $safeprojectname$.Core
{
    public class AdminUser
    {
        public string? Username { get; set; }
        public ClaimsIdentity? FullName { get; internal set; }

        public string Role = "Admin";

        public AdminUser(string? username)
        {
            Username = username;
        }
    }
    public class AdminPanelSettings
    {
        public required string Username { get; set; }
        private string _password = String.Empty;


        public required string Password
        {
            get => _password;
            set => _password = HashPasswordSHA1(value);
        }

        private static string HashPasswordSHA1(string password)
        {
            byte[] hashBytes = SHA1.HashData(Encoding.UTF8.GetBytes(password));
            StringBuilder builder = new();

            foreach (byte b in hashBytes)
            {
                builder.Append(b.ToString("x2"));
            }

            return builder.ToString();
        }

        static bool VerifyPasswordSHA1(string password, string hashedPassword)
        {
            string newHashedPassword = HashPasswordSHA1(password);
            return newHashedPassword == hashedPassword;
        }

        public AdminUser? AuthenticateUser(string username, string password)
        {
            AdminUser? user = null;
            if(this.Username == username && VerifyPasswordSHA1(password, this.Password))
            {
                user = new AdminUser(username);
            }
            return user;
        }
    }
}
