﻿using Microsoft.Extensions.Options;
using $safeprojectname$.Core;
using $safeprojectname$.Models;

namespace $safeprojectname$.Services
{
    public class UsersDbService : DbContext<User>
    {
        public UsersDbService(IOptions<DatabaseSettings> databaseSettings) : base(databaseSettings, databaseSettings.Value.UsersCollectionName)
        {
        }
    }
}
